domain_counts = dict()
 
fname = input('Masukkan nama file: ')
try:
    fhand = open(fname)
except FileNotFoundError:
    print('File tidak dapat dibuka:', fname)
    exit()
 
for line in fhand:
    # Cari baris yang dimulai dengan "From " (bukan "From:")
    if not line.startswith('From '):
        continue
    words = line.split()
    # Kata kedua adalah alamat email, ambil bagian setelah '@'
    email = words[1]
    domain = email.split('@')[1]
    domain_counts[domain] = domain_counts.get(domain, 0) + 1
 
print(domain_counts)