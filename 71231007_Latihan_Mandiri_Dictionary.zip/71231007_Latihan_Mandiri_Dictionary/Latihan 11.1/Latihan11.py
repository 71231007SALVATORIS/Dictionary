dictionary = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}  # membuat dictionary dengan pasangan key:value

print(f"{'key':<10} {'value':<10} {'item':<10}")  # mencetak header kolom dengan lebar 10 karakter
for key, value in dictionary.items():  # mengambil semua pasangan key dan value sekaligus
    print(f"{key:<10} {value:<10} {key:<10}")  # mencetak key, value, dan item (key) dalam format kolom rapi