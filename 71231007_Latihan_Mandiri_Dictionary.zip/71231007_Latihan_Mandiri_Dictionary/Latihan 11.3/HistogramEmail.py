fname = input('Masukkan nama file : ')  # meminta input nama file dari pengguna
try:
    fhand = open(fname)  # membuka file
except FileNotFoundError:
    print('File tidak bisa dibuka:', fname)  # menampilkan pesan error jika file tidak ditemukan
    exit()  # menghentikan program

counts = dict()  # membuat dictionary kosong untuk menyimpan hitungan email
for line in fhand:  # membaca file baris per baris
    if not line.startswith('From '):  # hanya proses baris yang diawali 'From '
        continue
    words = line.split()    # memecah baris menjadi list kata
    email = words[1]        # mengambil kata kedua yaitu alamat email pengirim
    counts[email] = counts.get(email, 0) + 1  # menambah hitungan email, default 0 jika belum ada

print(counts)  # mencetak dictionary hasil hitungan