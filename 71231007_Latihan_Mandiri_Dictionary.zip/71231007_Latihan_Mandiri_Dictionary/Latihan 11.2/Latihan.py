lista = ['red', 'green', 'blue']           # list pertama berisi nama warna
listb = ['#FF0000', '#008000', '#0000FF']  # list kedua berisi kode warna hex

hasil = dict(zip(lista, listb))  # zip menggabungkan dua list berpasangan, dict mengubahnya jadi dictionary
print(hasil)                     # mencetak dictionary hasil pemetaan
